My name is Alyssa Andrichik and I am a senior political science major at Reed College.
This repository consists of the labs I have done in my Data Science course in Spring 2021. 
